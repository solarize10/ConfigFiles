package com.danske.loanapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.danske.loanapp.models.Customer;
import com.danske.loanapp.models.CustomerKey;
import com.danske.loanapp.services.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
    //adding customer
	@PostMapping("/customers")
	//CORS issue
	@CrossOrigin("*")
	public ResponseEntity<?>  addCustomer(@RequestBody Customer customer)
	{
		Customer cust=customerService.addCustomer(customer);
		if(cust!=null)
			return ResponseEntity.ok(cust);
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer Object Not Added");
	}
	
	//fetching customer details
	@GetMapping("/customers")
	@CrossOrigin("*")
	public List<Customer> fetchAllCustomers()
	{
		return customerService.getAllCustomers();
	}
	//fetching customer details
	@GetMapping("/customers/{customerId}/{accountNo}")
	@CrossOrigin("*")
	public ResponseEntity<?> fetchCustomerByKey(@PathVariable("customerId") long customerId,
			@PathVariable("accountNo") long accountNo)
	{
		Customer cust=customerService.getCustomerByKey(new CustomerKey(customerId,accountNo));		
		if(cust!=null)
			return ResponseEntity.ok(cust);
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer record not found");
	}

	//delete by customer id
	@DeleteMapping("/customers/{customerId}/{accountNo}")
	@CrossOrigin("*")
	public ResponseEntity<?> deleteCustomerByKey(@PathVariable("customerId") long customerId,
			@PathVariable("accountNo") long accountNo)
	{
		boolean status=customerService.deleteCustomerByKey(new CustomerKey(customerId,accountNo));		
		if(status)
			return ResponseEntity.ok(customerId+"Record Deleted");
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer record not found and not deleted");
	}
	
	
	@PutMapping("/customers")
	//CORS issue
	@CrossOrigin("*")
	public ResponseEntity<?>  updateCustomer(@RequestBody Customer customer)
	{
		Customer cust=customerService.updateCustomer(customer);
		if(cust!=null)
			return ResponseEntity.ok(cust);
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer Object Not updated");
	}
	

}
