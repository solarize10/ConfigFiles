package com.danske.loanapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danske.loanapp.models.Customer;
import com.danske.loanapp.models.CustomerKey;

public interface CustomerRepository extends JpaRepository<Customer,CustomerKey> {

}
