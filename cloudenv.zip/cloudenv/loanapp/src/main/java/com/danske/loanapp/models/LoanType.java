package com.danske.loanapp.models;

public enum LoanType {
  HOME,CAR,JEWELLERY,EDUCATION
}
