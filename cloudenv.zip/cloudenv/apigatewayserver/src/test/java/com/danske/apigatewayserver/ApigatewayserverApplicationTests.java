package com.danske.apigatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
