package com.danske.loanapp.models;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="SB_Loan")
public class Loan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Loan_No")
     private long loanNo;
	@Enumerated(EnumType.STRING)
	@Column(name="Loan_Type",nullable =false,length = 100)
     private LoanType loanType;
	@Column(name="Amount")
     private long amount;
	@Column(name="ROI")
     private float roi;
	@Column(name="Tenure")
     private int tenure;
	@DateTimeFormat(iso = ISO.DATE)
	@Column(name="Issue_Date")
	 private LocalDate issueDate;
	//relationship
	@ManyToOne(fetch = FetchType.LAZY)
	//@JoinColumn(name = "Customer_Key",nullable = false)
	@JoinColumn(name="Customer_Id",nullable = false)
    @JoinColumn(name="Account_No",nullable = false) 
	@JsonIgnore
	private Customer customer;
}
